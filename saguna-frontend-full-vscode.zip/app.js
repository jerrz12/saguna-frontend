const state = { isAuthed:false, displayName:"Jerry" };

const recentStartups = [
  { company: "company 1", funding: 120000, founder: "Founder 1", stage: "Pre-Launch", founded: "02/15/2026", priority: "High" },
  { company: "company 2", funding: 80000, founder: "Founder 2", stage: "Launched", founded: "02/11/2026", priority: "High" },
  { company: "company 3", funding: 56000, founder: "Founder 3", stage: "Pre-Launch", founded: "02/10/2026", priority: "High" },
  { company: "company 4", funding: 6000, founder: "Founder 4", stage: "Pre-Launch", founded: "01/10/2026", priority: "Medium" },
  { company: "company 5", funding: null, founder: "Founder 5", stage: "Launched", founded: "01/01/2026", priority: "Low" }
];

const leads = [
  { company:"company 1", sector:"Sector_1", why:"Reason_1", sources:"Source_1", score:91, status:"New Lead" },
  { company:"company 2", sector:"Sector_2", why:"Reason_2", sources:"Source_1", score:84, status:"Contacted" },
  { company:"company 3", sector:"Sector_1", why:"Reason_3", sources:"Source_1", score:78, status:"New Lead" },
  { company:"company 4", sector:"Sector_3", why:"Reason_1", sources:"Source_1", score:76, status:"New Lead" },
  { company:"company 6", sector:"Sector_1", why:"Reason_1", sources:"Source_1", score:73, status:"New Lead" },
  { company:"company 5", sector:"Sector_1", why:"Reason_1", sources:"Source_1", score:70, status:"Not Fit" }
];

const els = {
  topbar: document.getElementById("topbar"),
  sidebar: document.getElementById("sidebar"),
  avatar: document.getElementById("avatar"),
  pages: Array.from(document.querySelectorAll("[data-page]")),
  navItems: Array.from(document.querySelectorAll(".navItem")),
  loginForm: document.getElementById("loginForm"),
  startupSearch: document.getElementById("startupSearch"),
  recentTbody: document.querySelector("#recentTable tbody"),
  leadsTbody: document.querySelector("#leadsTable tbody"),
  sectorFilter: document.getElementById("sectorFilter"),
  sourceFilter: document.getElementById("sourceFilter"),
  scoreMin: document.getElementById("scoreMin"),
  scoreLabel: document.getElementById("scoreLabel"),
  leadSearch: document.getElementById("leadSearch"),
  displayName: document.getElementById("displayName"),
  logoutBtn: document.getElementById("logoutBtn"),
};

function money(v){ return (v===null||v===undefined) ? "$Unknown" : "$"+Number(v).toLocaleString(); }
function priorityPill(p){ return `<span class="pill ${p.toLowerCase()}">${p}</span>`; }

function setAuthed(on){
  state.isAuthed = on;
  els.topbar.style.display = on ? "flex" : "none";
  els.sidebar.style.display = on ? "block" : "none";
  navigate(on ? "dashboard" : "login");
}

function navigate(route){
  els.pages.forEach(p => p.hidden = p.getAttribute("data-page") !== route);
  els.navItems.forEach(b => b.classList.toggle("active", b.dataset.route === route));
}

function renderRecent(q=""){
  const s = q.trim().toLowerCase();
  els.recentTbody.innerHTML = recentStartups
    .filter(x => !s || x.company.toLowerCase().includes(s) || x.founder.toLowerCase().includes(s))
    .map(x => `
      <tr>
        <td>${x.company}</td><td>${money(x.funding)}</td><td>${x.founder}</td>
        <td>${x.stage}</td><td>${x.founded}</td><td>${priorityPill(x.priority)}</td>
        <td class="right"><a class="viewLink" href="#" onclick="return false;">View</a></td>
      </tr>
    `).join("") || `<tr><td colspan="7" class="muted">No results.</td></tr>`;
}

function renderLeads(){
  const sector = els.sectorFilter.value;
  const source = els.sourceFilter.value;
  const minScore = Number(els.scoreMin.value);
  const q = els.leadSearch.value.trim().toLowerCase();
  els.scoreLabel.textContent = String(minScore);

  els.leadsTbody.innerHTML = leads
    .filter(l => sector==="all" || l.sector===sector)
    .filter(l => source==="all" || l.sources===source)
    .filter(l => l.score>=minScore)
    .filter(l => !q || l.company.toLowerCase().includes(q) || l.why.toLowerCase().includes(q))
    .map(l => `
      <tr><td>${l.company}</td><td>${l.sector}</td><td>${l.why}</td><td>${l.sources}</td><td>${l.score}</td><td>${l.status}</td></tr>
    `).join("") || `<tr><td colspan="6" class="muted">No results.</td></tr>`;
}

els.navItems.forEach(b => b.addEventListener("click", () => state.isAuthed && navigate(b.dataset.route)));
els.loginForm.addEventListener("submit", (e)=>{ e.preventDefault(); setAuthed(true); });
els.startupSearch.addEventListener("input", (e)=>renderRecent(e.target.value));
[els.sectorFilter, els.sourceFilter, els.scoreMin].forEach(el => el.addEventListener("input", renderLeads));
els.leadSearch.addEventListener("input", renderLeads);
els.logoutBtn.addEventListener("click", ()=>setAuthed(false));
els.displayName.addEventListener("input", (e)=>{ state.displayName=e.target.value||"Jerry"; els.avatar.textContent=(state.displayName.trim()[0]||"J").toUpperCase(); });

(function init(){
  setAuthed(false);
  els.avatar.textContent=(state.displayName.trim()[0]||"J").toUpperCase();
  renderRecent("");
  renderLeads();
})();
